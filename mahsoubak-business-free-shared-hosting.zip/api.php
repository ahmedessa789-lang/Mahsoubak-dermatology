<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$dataDir = __DIR__ . '/data';
$dbFile = $dataDir . '/db.json';

if (!is_dir($dataDir)) {
    mkdir($dataDir, 0755, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (!file_exists($dbFile)) {
        echo json_encode(['db' => null, 'updatedAt' => null], JSON_UNESCAPED_UNICODE);
        exit;
    }
    readfile($dbFile);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    $payload = json_decode($raw, true);

    if (!$payload || !isset($payload['db']) || !is_array($payload['db'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid database payload'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $saved = [
        'db' => $payload['db'],
        'updatedAt' => gmdate('c')
    ];

    file_put_contents($dbFile, json_encode($saved, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
    echo json_encode(['ok' => true, 'updatedAt' => $saved['updatedAt']], JSON_UNESCAPED_UNICODE);
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'Method not allowed'], JSON_UNESCAPED_UNICODE);

