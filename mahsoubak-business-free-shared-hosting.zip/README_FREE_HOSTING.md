# Free Shared Hosting Version

Use this version when you do not want Render, GitHub, or a credit card.

## Recommended Free Host

InfinityFree supports PHP and file hosting, so this app can save the shared database through `api.php`.

## Files To Upload

Upload these files to the hosting file manager, usually inside `htdocs`:

- `index.html`
- `api.php`

The app will create this folder automatically:

- `data/db.json`

## Steps

1. Create an account on https://www.infinityfree.com
2. Create a free hosting account.
3. Open File Manager.
4. Open the `htdocs` folder.
5. Upload `index.html` and `api.php`.
6. Open your free domain.

## Data

All users who open the same link will read and save the same data through `api.php`.

This is good for a demo or light client usage. For heavy real production usage, use a proper database later.

